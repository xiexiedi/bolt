import React from 'react';
import { User, Mail, Book, BookHeart, Compass, Moon, LogOut, ChevronRight, Settings } from 'lucide-react';

export const Profile: React.FC = () => {
  return (
    <div className="py-6 space-y-8">
      <div className="flex flex-col items-center">
        <div className="w-24 h-24 bg-indigo-600/30 rounded-full flex items-center justify-center border-2 border-indigo-400/30 mb-4">
          <User className="w-12 h-12 text-indigo-200" />
        </div>
        <h2 className="text-xl font-bold text-white">Mystic Seeker</h2>
        <p className="text-indigo-200/70 text-sm">member since April 2025</p>
      </div>
      
      {/* User Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 text-center">
          <p className="text-2xl font-bold text-white">24</p>
          <p className="text-xs text-indigo-200/70">Readings</p>
        </div>
        <div className="bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 text-center">
          <p className="text-2xl font-bold text-white">7</p>
          <p className="text-xs text-indigo-200/70">Favorites</p>
        </div>
        <div className="bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 text-center">
          <p className="text-2xl font-bold text-white">12</p>
          <p className="text-xs text-indigo-200/70">Journals</p>
        </div>
      </div>
      
      {/* Menu Options */}
      <div className="space-y-2">
        <h3 className="text-lg font-semibold text-white mb-3">Account</h3>
        
        <div className="space-y-2">
          <button className="w-full flex items-center justify-between bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 text-white">
            <div className="flex items-center">
              <Mail className="w-5 h-5 mr-3 text-indigo-300" />
              <span>Email Preferences</span>
            </div>
            <ChevronRight className="w-5 h-5 text-indigo-300" />
          </button>
          
          <button className="w-full flex items-center justify-between bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 text-white">
            <div className="flex items-center">
              <Settings className="w-5 h-5 mr-3 text-indigo-300" />
              <span>App Settings</span>
            </div>
            <ChevronRight className="w-5 h-5 text-indigo-300" />
          </button>
          
          <button className="w-full flex items-center justify-between bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 text-white">
            <div className="flex items-center">
              <Moon className="w-5 h-5 mr-3 text-indigo-300" />
              <span>Appearance</span>
            </div>
            <ChevronRight className="w-5 h-5 text-indigo-300" />
          </button>
        </div>
      </div>
      
      {/* Activities */}
      <div className="space-y-2">
        <h3 className="text-lg font-semibold text-white mb-3">Activities</h3>
        
        <div className="space-y-2">
          <button className="w-full flex items-center justify-between bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 text-white">
            <div className="flex items-center">
              <Compass className="w-5 h-5 mr-3 text-indigo-300" />
              <span>Reading History</span>
            </div>
            <ChevronRight className="w-5 h-5 text-indigo-300" />
          </button>
          
          <button className="w-full flex items-center justify-between bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 text-white">
            <div className="flex items-center">
              <BookHeart className="w-5 h-5 mr-3 text-indigo-300" />
              <span>Saved Readings</span>
            </div>
            <ChevronRight className="w-5 h-5 text-indigo-300" />
          </button>
          
          <button className="w-full flex items-center justify-between bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 text-white">
            <div className="flex items-center">
              <Book className="w-5 h-5 mr-3 text-indigo-300" />
              <span>Journal Entries</span>
            </div>
            <ChevronRight className="w-5 h-5 text-indigo-300" />
          </button>
        </div>
      </div>
      
      {/* Logout Button */}
      <button className="w-full flex items-center justify-center bg-red-900/30 text-red-300 rounded-xl p-4 border border-red-700/40 mt-8 hover:bg-red-900/50 transition-colors">
        <LogOut className="w-5 h-5 mr-2" />
        Sign Out
      </button>
    </div>
  );
};