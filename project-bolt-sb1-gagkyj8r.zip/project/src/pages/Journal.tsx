import React from 'react';
import { BookOpen, PenLine, Search, Calendar, ArrowUpCircle } from 'lucide-react';

export const Journal: React.FC = () => {
  // Mock journal entries
  const journalEntries = [
    {
      id: 1,
      date: 'April 12, 2025',
      title: 'The Fool\'s Journey',
      content: 'Today I reflected on the meaning of The Fool card in my daily draw. Starting a new project with optimism.',
      mood: 'Inspired'
    },
    {
      id: 2,
      date: 'April 10, 2025',
      title: 'Tower Moment',
      content: 'Unexpected change at work today. The Tower card was eerily accurate in predicting disruption.',
      mood: 'Reflective'
    },
    {
      id: 3,
      date: 'April 5, 2025',
      title: 'Full Moon Spread',
      content: 'Performed a special reading under the full moon. The High Priestess appeared, suggesting I trust my intuition more.',
      mood: 'Mystical'
    }
  ];

  const [showScrollTop, setShowScrollTop] = React.useState(false);
  
  React.useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="py-6 pb-20 relative">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Tarot Journal</h2>
        <div className="flex space-x-3">
          <button className="p-2 rounded-full bg-blue-800/50 text-indigo-200">
            <Search className="w-5 h-5" />
          </button>
          <button className="p-2 rounded-full bg-blue-800/50 text-indigo-200">
            <Calendar className="w-5 h-5" />
          </button>
        </div>
      </div>
      
      {/* New Entry Button */}
      <button className="w-full bg-gradient-to-r from-indigo-700 to-purple-700 hover:from-indigo-800 hover:to-purple-800 text-white px-4 py-3 rounded-xl mb-8 transition-all duration-300 flex items-center justify-center shadow-lg">
        <PenLine className="w-5 h-5 mr-2" />
        Write New Entry
      </button>
      
      {/* Journal Entries */}
      <div className="space-y-5">
        {journalEntries.map((entry) => (
          <div 
            key={entry.id}
            className="bg-blue-800/30 backdrop-blur-sm rounded-xl p-5 border border-blue-700/40 shadow-lg"
          >
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-semibold text-white">{entry.title}</h3>
              <div className="text-xs bg-blue-700/50 text-blue-200 py-1 px-2 rounded-full">
                {entry.mood}
              </div>
            </div>
            
            <p className="text-sm text-indigo-200/80 line-clamp-3 mb-3">
              {entry.content}
            </p>
            
            <div className="flex justify-between items-center">
              <div className="text-xs text-indigo-200/70">
                {entry.date}
              </div>
              <button className="text-indigo-300 text-sm hover:text-indigo-200 transition-colors flex items-center">
                <BookOpen className="w-4 h-4 mr-1" />
                Read More
              </button>
            </div>
          </div>
        ))}
        
        {/* More entries placeholders for scrolling */}
        {[...Array(5)].map((_, index) => (
          <div 
            key={`placeholder-${index}`}
            className="bg-blue-800/30 backdrop-blur-sm rounded-xl p-5 border border-blue-700/40 shadow-lg opacity-70"
          >
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-semibold text-white">Past Reading Insights</h3>
              <div className="text-xs bg-blue-700/50 text-blue-200 py-1 px-2 rounded-full">
                Reflective
              </div>
            </div>
            
            <p className="text-sm text-indigo-200/80 line-clamp-3 mb-3">
              Notes about recurring symbols in recent readings and their potential meanings in my life.
            </p>
            
            <div className="flex justify-between items-center">
              <div className="text-xs text-indigo-200/70">
                April {index + 1}, 2025
              </div>
              <button className="text-indigo-300 text-sm hover:text-indigo-200 transition-colors flex items-center">
                <BookOpen className="w-4 h-4 mr-1" />
                Read More
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {/* Scroll to top button */}
      {showScrollTop && (
        <button 
          onClick={scrollToTop}
          className="fixed bottom-20 right-4 bg-indigo-600/80 text-white p-2 rounded-full shadow-lg backdrop-blur-sm transition-all duration-300 hover:bg-indigo-600"
          aria-label="Scroll to top"
        >
          <ArrowUpCircle className="w-6 h-6" />
        </button>
      )}
    </div>
  );
};