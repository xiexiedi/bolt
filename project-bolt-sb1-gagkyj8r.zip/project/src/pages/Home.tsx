import React from 'react';
import { ChevronRight } from 'lucide-react';
import { SpreadOption } from '../components/SpreadOption';
import { TarotCard } from '../components/TarotCard';
import { DailyHoroscope } from '../components/DailyHoroscope';

export const Home: React.FC = () => {
  return (
    <div className="py-4 space-y-8">
      {/* Welcome Message */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white">Welcome Back</h2>
        <p className="text-indigo-200/80">What do the cards have in store for you today?</p>
      </div>
      
      {/* Spread Selection Section */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold text-white">Choose a Spread</h3>
          <button className="flex items-center text-indigo-300 text-sm">
            See All <ChevronRight className="w-4 h-4 ml-1" />
          </button>
        </div>
        
        <div className="flex overflow-x-auto pb-4 space-x-4 scrollbar-hide">
          <SpreadOption 
            title="Single Card" 
            description="Quick guidance for the day" 
            cardCount={1} 
          />
          <SpreadOption 
            title="Three Card" 
            description="Past, Present, Future" 
            cardCount={3} 
          />
          <SpreadOption 
            title="Celtic Cross" 
            description="Detailed life reading" 
            cardCount={10} 
          />
          <SpreadOption 
            title="Relationship" 
            description="Insight into connections" 
            cardCount={5} 
          />
        </div>
      </section>
      
      {/* Daily Horoscope */}
      <DailyHoroscope />
      
      {/* Recent Cards */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold text-white">Featured Cards</h3>
          <button className="flex items-center text-indigo-300 text-sm">
            View Deck <ChevronRight className="w-4 h-4 ml-1" />
          </button>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          <TarotCard name="The Fool" isReversed={false} />
          <TarotCard name="The Magician" isReversed={false} />
          <TarotCard name="The High Priestess" isReversed={true} />
          <TarotCard name="The Empress" isReversed={false} />
        </div>
      </section>
      
      {/* Beginner's Guide */}
      <section className="bg-blue-800/30 backdrop-blur-sm rounded-xl p-4 border border-blue-700/40 shadow-lg">
        <h3 className="text-lg font-semibold text-white mb-2">New to Tarot?</h3>
        <p className="text-indigo-200/80 mb-3">Discover the ancient art of tarot reading with our beginner's guide.</p>
        <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors">
          Start Learning
        </button>
      </section>
    </div>
  );
};