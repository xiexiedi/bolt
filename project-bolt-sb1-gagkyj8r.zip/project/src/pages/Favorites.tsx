import React from 'react';
import { TarotCard } from '../components/TarotCard';
import { CalendarDays, Star } from 'lucide-react';

export const Favorites: React.FC = () => {
  // Mock favorite readings
  const favoriteReadings = [
    {
      id: 1,
      date: 'April 10, 2025',
      title: 'Career Path Reading',
      cards: ['The Tower', 'Eight of Pentacles', 'The Star'],
      notes: 'Unexpected changes at work leading to growth opportunity'
    },
    {
      id: 2,
      date: 'March 28, 2025',
      title: 'Personal Growth',
      cards: ['The Hermit'],
      notes: 'Time for self-reflection and inner wisdom'
    }
  ];

  return (
    <div className="py-6 space-y-6">
      <h2 className="text-2xl font-bold text-white mb-4">Saved Readings</h2>
      
      {favoriteReadings.length > 0 ? (
        <div className="space-y-6">
          {favoriteReadings.map((reading) => (
            <div 
              key={reading.id}
              className="bg-blue-800/30 backdrop-blur-sm rounded-xl p-5 border border-blue-700/40 shadow-lg"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold text-white">{reading.title}</h3>
                  <div className="flex items-center text-xs text-indigo-200/70 mt-1">
                    <CalendarDays className="w-3 h-3 mr-1" />
                    {reading.date}
                  </div>
                </div>
                <button className="p-1 text-yellow-300">
                  <Star className="w-5 h-5 fill-current" />
                </button>
              </div>
              
              <div className="flex overflow-x-auto py-2 space-x-3 scrollbar-hide">
                {reading.cards.map((card, index) => (
                  <div key={index} className="w-24 flex-shrink-0">
                    <TarotCard name={card} isReversed={false} />
                  </div>
                ))}
              </div>
              
              <p className="text-sm text-indigo-200/80 mt-3 line-clamp-2">
                {reading.notes}
              </p>
              
              <button className="text-indigo-300 text-sm mt-3 hover:text-indigo-200 transition-colors">
                View Complete Reading
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <Star className="w-16 h-16 text-indigo-300/50 mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">No Saved Readings Yet</h3>
          <p className="text-indigo-200/70 max-w-xs mx-auto">
            Your favorite and saved readings will appear here for easy access.
          </p>
          <button className="mt-6 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg transition-colors">
            Draw New Cards
          </button>
        </div>
      )}
    </div>
  );
};