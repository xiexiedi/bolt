import React, { useState } from 'react';
import { TarotCard } from '../components/TarotCard';
import { Sparkles, Info, Share2, Save } from 'lucide-react';

export const DrawCards: React.FC = () => {
  const [selectedSpread, setSelectedSpread] = useState<string | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawnCards, setDrawnCards] = useState<string[]>([]);

  const spreads = [
    { id: 'single', name: 'Single Card', count: 1 },
    { id: 'three', name: 'Three Card', count: 3 },
    { id: 'celtic', name: 'Celtic Cross', count: 10 }
  ];

  // Mock card names
  const allCardNames = [
    'The Fool', 'The Magician', 'The High Priestess', 'The Empress', 
    'The Emperor', 'The Hierophant', 'The Lovers', 'The Chariot'
  ];

  const drawCards = (count: number) => {
    setIsDrawing(true);
    
    // Simulate delay for drawing animation
    setTimeout(() => {
      // Randomly select cards
      const shuffled = [...allCardNames].sort(() => 0.5 - Math.random());
      const selected = shuffled.slice(0, count);
      setDrawnCards(selected);
      setIsDrawing(false);
    }, 1500);
  };

  return (
    <div className="py-6 space-y-6">
      <h2 className="text-2xl font-bold text-white mb-4">Draw Your Cards</h2>
      
      {/* Spread Selection */}
      {!selectedSpread && !drawnCards.length && (
        <div className="space-y-4">
          <p className="text-indigo-200/80 mb-6">Select a spread to begin your reading:</p>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {spreads.map((spread) => (
              <button
                key={spread.id}
                onClick={() => {
                  setSelectedSpread(spread.id);
                  drawCards(spread.count);
                }}
                className="bg-blue-800/30 backdrop-blur-sm hover:bg-blue-800/50 transition-all border border-blue-700/40 rounded-xl p-4 text-center hover:scale-105 duration-300"
              >
                <h3 className="text-lg font-semibold text-white">{spread.name}</h3>
                <p className="text-xs text-indigo-200/70 mt-1">{spread.count} Card{spread.count > 1 ? 's' : ''}</p>
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* Drawing Animation */}
      {isDrawing && (
        <div className="flex flex-col items-center justify-center py-12">
          <div className="relative">
            <Sparkles className="w-16 h-16 text-indigo-300 animate-pulse" />
            <div className="absolute inset-0 animate-spin duration-3000">
              <Sparkles className="w-16 h-16 text-purple-300 opacity-70" />
            </div>
          </div>
          <p className="text-indigo-200 mt-6 animate-pulse">Drawing your cards...</p>
        </div>
      )}
      
      {/* Drawn Cards Display */}
      {!isDrawing && drawnCards.length > 0 && (
        <div className="space-y-8">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Your Reading</h3>
            <div className="flex space-x-3">
              <button className="p-2 rounded-full bg-blue-800/50 text-indigo-200">
                <Info className="w-5 h-5" />
              </button>
              <button className="p-2 rounded-full bg-blue-800/50 text-indigo-200">
                <Share2 className="w-5 h-5" />
              </button>
              <button className="p-2 rounded-full bg-blue-800/50 text-indigo-200">
                <Save className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          <div className={`grid ${
            drawnCards.length === 1 ? 'place-items-center' : 
            drawnCards.length === 3 ? 'grid-cols-3 gap-4' : 
            'grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4'
          }`}>
            {drawnCards.map((card, index) => (
              <div key={index} className="flex flex-col items-center">
                <TarotCard 
                  name={card} 
                  isReversed={Math.random() > 0.7} 
                />
                <p className="mt-3 text-sm text-center text-indigo-200">
                  {drawnCards.length === 3 ? (
                    ['Past', 'Present', 'Future'][index]
                  ) : (
                    `Card ${index + 1}`
                  )}
                </p>
              </div>
            ))}
          </div>
          
          <div className="bg-blue-800/30 backdrop-blur-sm rounded-xl p-5 border border-blue-700/40 mt-8">
            <h4 className="text-lg font-semibold text-white mb-3">Reading Interpretation</h4>
            <p className="text-indigo-200/80 text-sm">
              The cards suggest a period of introspection and personal growth. 
              Pay attention to signs around you and trust your intuition as you 
              navigate upcoming challenges.
            </p>
          </div>
          
          <button 
            onClick={() => {
              setSelectedSpread(null);
              setDrawnCards([]);
            }}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg transition-colors mx-auto block mt-6"
          >
            New Reading
          </button>
        </div>
      )}
    </div>
  );
};