import React, { useState } from 'react';

interface TarotCardProps {
  name: string;
  isReversed?: boolean;
}

export const TarotCard: React.FC<TarotCardProps> = ({ 
  name, 
  isReversed = false 
}) => {
  const [isFlipped, setIsFlipped] = useState(false);

  // Generate a placeholder image URL based on the card name
  const getCardImageUrl = (cardName: string): string => {
    // Placeholder URL - in a real app, you'd use actual card images
    return `https://images.pexels.com/photos/6542600/pexels-photo-6542600.jpeg?auto=compress&cs=tinysrgb&w=600`;
  };

  // Get card back image
  const getCardBackImageUrl = (): string => {
    return `https://images.pexels.com/photos/7708806/pexels-photo-7708806.jpeg?auto=compress&cs=tinysrgb&w=600`;
  };

  const handleClick = () => {
    setIsFlipped(!isFlipped);
  };

  return (
    <div 
      className="aspect-[1/1.6] relative cursor-pointer perspective"
      onClick={handleClick}
    >
      <div 
        className={`w-full h-full transition-all duration-500 preserve-3d ${
          isFlipped ? 'rotate-y-180' : ''
        }`}
      >
        {/* Card back */}
        <div 
          className={`absolute w-full h-full backface-hidden rounded-lg shadow-lg overflow-hidden ${
            !isFlipped ? 'z-10' : 'z-0'
          }`}
        >
          <img 
            src={getCardBackImageUrl()} 
            alt="Tarot card back" 
            className="w-full h-full object-cover rounded-lg"
          />
        </div>

        {/* Card front */}
        <div 
          className={`absolute w-full h-full backface-hidden rounded-lg shadow-lg overflow-hidden rotate-y-180 ${
            isFlipped ? 'z-10' : 'z-0'
          } ${isReversed ? 'rotate-180' : ''}`}
        >
          <img 
            src={getCardImageUrl(name)} 
            alt={name} 
            className="w-full h-full object-cover rounded-lg"
          />
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2">
            <p className="text-white text-xs font-semibold">{name}</p>
            {isReversed && (
              <span className="text-red-300 text-[10px]">Reversed</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};